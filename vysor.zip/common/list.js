if (window.appcallback) {
  window.appcallback();
}